# html2rl
A python package that helps to convert HTML to XML like formal supported by the ReportLab Paragraph module.
